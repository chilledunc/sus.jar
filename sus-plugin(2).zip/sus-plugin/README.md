# SusPlugin

Ein Paper-Plugin, das verdächtige Aktivitäten (mögliches Cheating) erkennt und Staff-Mitgliedern
Werkzeuge zur Überprüfung und Bestrafung an die Hand gibt.

## Features

- **Automatische Erkennung** von:
  - Speed-Hacking (zu hohe Bewegungsgeschwindigkeit)
  - Fly-Hacking (unnatürliches Schweben)
  - KillAura / zu hoher Reach beim Angreifen
  - Autoclicker (zu hohe CPS)
- **`/sus`** – Öffnet eine GUI mit allen aktuell verdächtigen Spielern (Spielerkopf + Score + letzte Meldungen)
- **Klick auf einen Spieler in der GUI** – Staff wird in den Spectator-Modus versetzt und "spectatet" direkt den Zielspieler
- **`/susback`** – Staff kehrt zum vorherigen Gamemode/Standort zurück
- **`/offend <Spieler> <Grund>`** – Bannt den Spieler sofort (permanent) und benachrichtigt alle Staff-Mitglieder
- **Discord-Webhook** – Sendet bei jedem Bann automatisch eine Embed-Nachricht an einen Discord-Channel (optional auch bei jedem neuen Verdachtsfall)

## Discord-Webhook

In `config.yml` (wird beim ersten Start automatisch im Plugin-Ordner erzeugt) kannst du die
Benachrichtigung konfigurieren:

```yaml
discord:
  enabled: true
  webhook-url: "https://discordapp.com/api/webhooks/DEINE_WEBHOOK_URL"
  notify-on-flag: false   # true = auch bei jedem einzelnen Verdachtsfall senden (kann spammen!)
  username: "SusPlugin"
```

Die Webhook-URL ist bereits mit deiner URL vorbelegt. **Wichtig:** Diese URL ist quasi ein
Passwort – jeder, der sie kennt, kann Nachrichten in deinen Discord-Channel posten. Teile sie
nicht öffentlich (z.B. nicht in einem öffentlichen GitHub-Repo committen) und rotiere sie in den
Discord-Kanaleinstellungen, falls sie doch mal versehentlich geleakt sein sollte.

Die Anfragen laufen komplett asynchron über den Bukkit-Scheduler, sodass ein langsamer oder
nicht erreichbarer Discord-Server niemals den Spiel-Tick blockiert.

## Berechtigungen

| Permission     | Beschreibung                                  | Default |
|----------------|------------------------------------------------|---------|
| `sus.staff`    | Nutzung von `/sus` und `/susback`, GUI-Zugriff | op      |
| `sus.ban`      | Nutzung von `/offend`                          | op      |
| `sus.notify`   | Erhält Live-Chat-Warnungen bei Verdachtsfällen  | op      |
| `sus.bypass`   | Spieler mit dieser Permission werden nicht überwacht (z.B. für Staff selbst) | - |

## Bauen (3 Optionen)

### Option A – GitHub Actions (empfohlen, kein lokales Java/Maven nötig!)

1. Erstelle ein neues, leeres Repository auf https://github.com/new (kann privat sein)
2. Lade den kompletten Inhalt dieses Ordners (inkl. `.github`-Ordner!) dort hoch
   (per Drag & Drop im Browser über "Add file" → "Upload files", oder per `git push`)
3. Gehe im Repository auf den Tab **„Actions"** – der Workflow „Build Plugin" startet automatisch
4. Warte ca. 1-2 Minuten bis der Lauf grün ist (Häkchen)
5. Klicke den Lauf an → unten bei **„Artifacts"** liegt `SusPlugin.zip` zum Download
   (darin ist die fertige `SusPlugin.jar`)
6. Diese `.jar` in deinen `plugins`-Ordner hochladen, Server neu starten

GitHub Actions hat vollen Internetzugriff und kann problemlos die Paper-API von
`repo.papermc.io` herunterladen – dort scheitert es lokal oft nicht, aber falls doch
(Firewall, fehlendes Java), ist das hier der zuverlässigste Weg.

### Option B – IntelliJ IDEA Community (kostenlos, mit GUI)

1. IntelliJ IDEA Community installieren: https://www.jetbrains.com/idea/download/
2. Diesen Ordner als Projekt öffnen (`File → Open`)
3. IntelliJ erkennt automatisch Maven und lädt Abhängigkeiten
4. Rechts am Rand auf „Maven" → `Lifecycle` → Doppelklick auf `package`
5. Fertige `.jar` liegt in `target/SusPlugin.jar`

### Option C – Maven manuell installieren

Voraussetzungen: Java 21+, Maven (im PATH).

```bash
mvn clean package
```

Die fertige Datei liegt danach unter `target/SusPlugin.jar`. Diese Datei in den `plugins`-Ordner
deines Paper-Servers kopieren und den Server neu starten.

## Wichtiger Hinweis zu Paper 26.2

Dieses Projekt ist auf **Paper 26.2** (Minecraft 26.2) eingestellt, inkl. Java 21+ Kompatibilität
und der neuen `BanList.Type.PROFILE`-API (Bans per Spielername werden von neueren Paper-Versionen
nicht mehr unterstützt). Da diese Serverversion sehr neu ist, kann es sein, dass beim ersten Build
noch kleinere Anpassungen nötig sind – schau in dem Fall in die Fehlermeldung des Builds, meistens
verrät sie genau, welche Klasse/Methode sich geändert hat.

## Wichtige Hinweise

- Dies ist ein **Grund-Framework** mit einfachen Heuristiken, kein vollwertiger Anti-Cheat wie
  NoCheatPlus. Die Schwellenwerte in `AntiCheatListener.java` (z.B. `MAX_HORIZONTAL_SPEED`,
  `MAX_ATTACK_REACH`, `MAX_CPS`) solltest du an deinen Server (Ping der Spieler, TPS, andere Plugins
  wie Grappling-Hooks, Speed-Effekte durch Kits usw.) anpassen, um False Positives zu vermeiden.
- Die Verdachts-Einträge werden nur im Arbeitsspeicher gehalten (nicht persistent). Nach einem
  Server-Neustart sind alle Meldungen zurückgesetzt.
- `/offend` nutzt die Standard-Bukkit BanList (`banned-players.json` bzw. `banned-players.txt` je
  nach Serverversion), also den normalen Minecraft-Bann-Mechanismus.
- Passe bei Bedarf die `api-version` in `plugin.yml` und die Paper-API-Version in `pom.xml` an
  deine tatsächliche Serverversion an.

## Mögliche Erweiterungen (optional)

- Persistente Speicherung der Verdachtsfälle (z.B. via SQLite/YAML), damit sie einen Neustart überleben
- Eigene History/Log-Datei pro Bann für Nachvollziehbarkeit
- Zusätzliche Checks: Scaffold/Fast-Place, NoSlowdown, AutoTotem
- Bestätigungs-GUI vor dem Bann (statt direktem Chat-Command)
